package com.cristiano.cartaodevacina

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import java.io.File

private lateinit var nomeCom : EditText
private lateinit var imagemUsuario : Button
private lateinit var endcompleto : EditText
private lateinit var numero : EditText
private lateinit var cpf : EditText
private lateinit var senha : EditText
private const val REQUEST_CODE = 13
private lateinit var filePhoto: File
private const val FILE_NAME = "photo.jpg"

class Cadastro : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cadastro)

        nomeCom = findViewById(R.id.nomeCom)
        imagemUsuario = findViewById(R.id.imagemUsuario)
        endcompleto = findViewById(R.id.endcompleto)
        numero = findViewById(R.id.numero)
        cpf = findViewById(R.id.cpf)
        senha = findViewById(R.id.senha)

        var btCadastrar = findViewById<Button>(R.id.registrar)
        btCadastrar.setOnClickListener {

            if (savedInstanceState != null) {
                nomeCom.setText(savedInstanceState.getString("fullName"))
                imagemUsuario.isClickable()
                endcompleto.setText(savedInstanceState.getString("fullAddress"))
                numero.setText(savedInstanceState.getString("number"))
                cpf.setText(savedInstanceState.getString("cpf"))
                senha.setText(savedInstanceState.getString("password"))
            }
            if (nomeCom.text.toString().isEmpty()) {
                Toast.makeText(this, "Verifique se você adicionou um nome", Toast.LENGTH_SHORT).show();
            } else if (endcompleto.text.toString().isEmpty()) {
                Toast.makeText(this, "Verifique se você adicionou um endereço", Toast.LENGTH_SHORT)
                    .show();
            } else if (numero.text.toString().isEmpty()) {
                Toast.makeText(this, "Verifique se você adicionou um numero", Toast.LENGTH_SHORT)
                    .show();
            } else if (cpf.text.toString().isEmpty()) {
                Toast.makeText(this, "Verifique se você adicionou um cpf", Toast.LENGTH_SHORT).show();
            } else if (senha.text.toString().isEmpty()) {
                Toast.makeText(this, "Verifique se você adicionou uma senha", Toast.LENGTH_SHORT)
                    .show();
            } else if (senha.text.toString().isNotEmpty()) {

                val mensagem =
                    "Cadastro realizado com sucesso, agora você pode logar em nosso APP e continuar seu cadastro...."
                val duration = Toast.LENGTH_SHORT

                val toast = Toast.makeText(applicationContext, mensagem, duration)
                toast.show()
            } else {
                val mensagem = "Por favor, preencha o formulário!"
                val duration = Toast.LENGTH_SHORT

                val toast = Toast.makeText(applicationContext, mensagem, duration)
                toast.show()
            }

            imagemUsuario.setOnClickListener {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
                        val permissions = arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
                        requestPermissions(permissions, PERMISSION_CODE)
                    } else {
                        chooseImageGallery();

                    }
                } else {
                    chooseImageGallery();

                }

            }
        }

    }

    private fun chooseImageGallery() {
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"
        startActivityForResult(intent, IMAGE_CHOOSE)
    }

    companion object {
        private val IMAGE_CHOOSE = 1000;
        private val PERMISSION_CODE = 1001;
    }

    override fun onSaveInstanceState(outState: Bundle) {

        outState.putString("fullName", nomeCom.text.toString())
        outState.putString("fullAddress", endcompleto.text.toString())
        outState.putString("number", numero.text.toString())
        outState.putString("cpf", cpf.text.toString())
        outState.putString("password", senha.text.toString())

        super.onSaveInstanceState(outState)
    }
}